class Queue {
  constructor() {
    this.data = [];
  }

  enqueue(element) {
  }

  dequeue() {
  }

  peek() {
  }

  size() {
  }
}
